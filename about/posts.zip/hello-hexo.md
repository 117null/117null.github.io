---
title: Hello,Yaoyongqin
date: 2023-02-24 20:20:00
tags: 技术
---
Welcome! This is your very first post. Check [documentation](https://hexo.io/docs/) for more info. If you get any problems when using Hexo, you can find the answer in [troubleshooting](https://hexo.io/docs/troubleshooting.html) or you can ask me on [GitHub](https://github.com/hexojs/hexo/issues).
### Run server
$ hexo server
More info: [Server](https://hexo.io/docs/server.html)
### Generate static files
$ hexo generate
More info: [Generating](https://hexo.io/docs/generating.html)
